-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.13


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema uca
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ uca;
USE uca;

--
-- Table structure for table `uca`.`addassignment`
--

DROP TABLE IF EXISTS `addassignment`;
CREATE TABLE `addassignment` (
  `date` varchar(50) DEFAULT NULL,
  `class1` varchar(50) DEFAULT NULL,
  `semester` varchar(50) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `assignment` longblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`addassignment`
--

/*!40000 ALTER TABLE `addassignment` DISABLE KEYS */;
INSERT INTO `addassignment` (`date`,`class1`,`semester`,`title`,`assignment`) VALUES 
 ('2023-07-02','BCA','6','System Programming',0x56492053454D20424341205350284750292E646F6378),
 ('2023-07-06','BCA','6','System Programming',0x41737369676E6D656E745F322053502E646F6378),
 ('2023-07-02','BCA','6','Web Programming',0x57502061737369676E6D656E742D312E646F6378),
 ('2023-07-02','BCA','6','CNS',0x434E535F41535349474E4D454E542E646F6378),
 ('2023-07-01','BCA','5','MP',0x4D502041737369676E6D656E7420322E646F6378),
 ('','BCA','6','CNS',0x434E535F41535349474E4D454E542E646F6378),
 ('2023-07-08','BCA','5','MP',0x4D502041737369676E6D656E7420322E646F6378);
/*!40000 ALTER TABLE `addassignment` ENABLE KEYS */;


--
-- Table structure for table `uca`.`addtt`
--

DROP TABLE IF EXISTS `addtt`;
CREATE TABLE `addtt` (
  `class` varchar(50) DEFAULT NULL,
  `semester` varchar(50) DEFAULT NULL,
  `M1` varchar(50) DEFAULT NULL,
  `M2` varchar(50) DEFAULT NULL,
  `M3` varchar(50) DEFAULT NULL,
  `M4` varchar(50) DEFAULT NULL,
  `T1` varchar(50) DEFAULT NULL,
  `T2` varchar(50) DEFAULT NULL,
  `T3` varchar(50) DEFAULT NULL,
  `T4` varchar(50) DEFAULT NULL,
  `W1` varchar(50) DEFAULT NULL,
  `W2` varchar(50) DEFAULT NULL,
  `W3` varchar(50) DEFAULT NULL,
  `W4` varchar(50) DEFAULT NULL,
  `Th1` varchar(50) DEFAULT NULL,
  `Th2` varchar(50) DEFAULT NULL,
  `Th3` varchar(50) DEFAULT NULL,
  `Th4` varchar(50) DEFAULT NULL,
  `F1` varchar(50) DEFAULT NULL,
  `F2` varchar(50) DEFAULT NULL,
  `F3` varchar(50) DEFAULT NULL,
  `F4` varchar(50) DEFAULT NULL,
  `S1` varchar(50) DEFAULT NULL,
  `S2` varchar(50) DEFAULT NULL,
  `S3` varchar(50) DEFAULT NULL,
  `S4` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`addtt`
--

/*!40000 ALTER TABLE `addtt` DISABLE KEYS */;
INSERT INTO `addtt` (`class`,`semester`,`M1`,`M2`,`M3`,`M4`,`T1`,`T2`,`T3`,`T4`,`W1`,`W2`,`W3`,`W4`,`Th1`,`Th2`,`Th3`,`Th4`,`F1`,`F2`,`F3`,`F4`,`S1`,`S2`,`S3`,`S4`) VALUES 
 ('BCA','6','Project','Project','WP','CNS','TOC','CNS','WP','SP','Project','Project','IT','TOC','CNS','SP','WP Lab(B1)','WP Lab(B1)','TOC','SP','WP Lab(B2)','WP Lab(B2)','SP','WP','CNS','TOC'),
 ('BCA','5','Mp','Java','DCN','B&I','B&I','DCN','Java','MP','MP','Java','DCN','SE','SE','Java','Mp','DCN','SE','CA','MP','CA','CA','Java','SE','Java');
/*!40000 ALTER TABLE `addtt` ENABLE KEYS */;


--
-- Table structure for table `uca`.`adminlogin`
--

DROP TABLE IF EXISTS `adminlogin`;
CREATE TABLE `adminlogin` (
  `userid` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`adminlogin`
--

/*!40000 ALTER TABLE `adminlogin` DISABLE KEYS */;
INSERT INTO `adminlogin` (`userid`,`password`) VALUES 
 ('admin1234','9630');
/*!40000 ALTER TABLE `adminlogin` ENABLE KEYS */;


--
-- Table structure for table `uca`.`contactus`
--

DROP TABLE IF EXISTS `contactus`;
CREATE TABLE `contactus` (
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`contactus`
--

/*!40000 ALTER TABLE `contactus` DISABLE KEYS */;
INSERT INTO `contactus` (`name`,`email`,`message`) VALUES 
 ('Lalith Seervi','seervilalith2202@gmail.com','Hello');
/*!40000 ALTER TABLE `contactus` ENABLE KEYS */;


--
-- Table structure for table `uca`.`facultyregister`
--

DROP TABLE IF EXISTS `facultyregister`;
CREATE TABLE `facultyregister` (
  `id` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `phoneno` varchar(50) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `dept` varchar(50) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `photo` longblob,
  `password` varchar(50) DEFAULT NULL,
  `confirmpass` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`facultyregister`
--

/*!40000 ALTER TABLE `facultyregister` DISABLE KEYS */;
INSERT INTO `facultyregister` (`id`,`name`,`dob`,`phoneno`,`emailid`,`dept`,`designation`,`photo`,`password`,`confirmpass`) VALUES 
 ('F08410','Ashwini','1995-07-05','7894561231','ashwini@gmail.com','BCA','Assistant Professor',0x68612E706E67,'050795','050795'),
 ('F17801','Gagana','1995-08-07','7894561230','gagana@gmail.com','BCA','Professor',0x686F6D652E6A7067,'070895','070895'),
 ('F05881','Asha','1992-12-15','7894561230','asha@gmail.com','BBA','Associate Professor',0x656D61696C2E706E67,'151292','151292'),
 ('F46510','Vikas','1991-06-23','7891234560','vikas@gmail.com','BBA','Assistant Professor',0x686F6D656C6F676F2E706E67,'230691','230691'),
 ('F60453','Ajay','1985-05-19','7891234560','ajay@gmail.com','B.Com','Assistant Professor',0x706C75732E706E67,'123654','123654'),
 ('F74719','Suresh','1980-01-30','7891234560','suresh@gmail.com','B.Com','Associate Professor',0x6D61726B732E706E67,'789456','789456'),
 ('F75958','Shivraj','1975-04-11','7891234560','shivraj@gmail.com','BBA','Assistant Professor',0x74696D657461626C652E706E67,'123456','123456'),
 ('F75958','Shivraj','1975-04-11','7891234560','shivraj@gmail.com','BBA','Assistant Professor',0x74696D657461626C652E706E67,'123456','123456');
INSERT INTO `facultyregister` (`id`,`name`,`dob`,`phoneno`,`emailid`,`dept`,`designation`,`photo`,`password`,`confirmpass`) VALUES 
 ('F78401','Varsha','1996-09-05','9876543231','varsha@gmail.com','B.Com','Assistant Professor',0x68612E706E67,'123','123'),
 ('F16840','Sahana','1992-06-15','7894561231','smartuni.faculty1@gmail.com','BCA','Assistant Professor',0x757365722E706E67,'9630','9630');
/*!40000 ALTER TABLE `facultyregister` ENABLE KEYS */;


--
-- Table structure for table `uca`.`markattendence`
--

DROP TABLE IF EXISTS `markattendence`;
CREATE TABLE `markattendence` (
  `date` varchar(50) DEFAULT NULL,
  `id` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `semester` varchar(50) DEFAULT NULL,
  `attendence` varchar(50) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`markattendence`
--

/*!40000 ALTER TABLE `markattendence` DISABLE KEYS */;
INSERT INTO `markattendence` (`date`,`id`,`name`,`course`,`semester`,`attendence`,`emailid`) VALUES 
 ('2023-07-18','S92113','Darshan','BCA','5','P','smartuni.student1@gmail.com'),
 ('2023-07-18','S23329','Nidhi','BCA','6','A','nidhisatish24@gmail.com'),
 ('2023-07-19','S22526','Varun','BCA','5','a','varun@gmail.com'),
 ('2023-07-19','S92113','Darshan','BCA','5','A','smartuni.student1@gmail.com');
/*!40000 ALTER TABLE `markattendence` ENABLE KEYS */;


--
-- Table structure for table `uca`.`notesfile`
--

DROP TABLE IF EXISTS `notesfile`;
CREATE TABLE `notesfile` (
  `FID` int(11) NOT NULL AUTO_INCREMENT,
  `File` longblob,
  `FileName` varchar(255) DEFAULT NULL,
  `FileType` varchar(20) DEFAULT NULL,
  `Course` varchar(20) DEFAULT NULL,
  `Semester` varchar(20) DEFAULT NULL,
  `SubjectName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`notesfile`
--

/*!40000 ALTER TABLE `notesfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `notesfile` ENABLE KEYS */;


--
-- Table structure for table `uca`.`publishfacultynotice`
--

DROP TABLE IF EXISTS `publishfacultynotice`;
CREATE TABLE `publishfacultynotice` (
  `date` varchar(50) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`publishfacultynotice`
--

/*!40000 ALTER TABLE `publishfacultynotice` DISABLE KEYS */;
INSERT INTO `publishfacultynotice` (`date`,`title`,`description`) VALUES 
 ('2023-07-04','WP Lab','Dear Students, you ll have unit 2 test at 2pm .'),
 ('2023-07-11','CNS','CNS Assignment to be submitted tomorrow.'),
 ('2023-07-05','Wp classtest','Dear Students, you ll have unit 2 test at 2pm .'),
 ('2023-07-04','CNS classtest','Dear Students, you ll have unit 2 test at 2pm .'),
 ('2023-07-14','TOC Classtest','Dear Students, you ll have unit 2 test at 3pm .');
/*!40000 ALTER TABLE `publishfacultynotice` ENABLE KEYS */;


--
-- Table structure for table `uca`.`publishnotice`
--

DROP TABLE IF EXISTS `publishnotice`;
CREATE TABLE `publishnotice` (
  `date` varchar(50) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`publishnotice`
--

/*!40000 ALTER TABLE `publishnotice` DISABLE KEYS */;
INSERT INTO `publishnotice` (`date`,`title`,`description`) VALUES 
 ('2023-07-03','Fee Payment Remainder','Please pay the balance fee before 10-07-2023'),
 ('2023-07-03','Hallticket Issue Date','Your annual exam halltickets will be issued on 15-07-2023.'),
 ('2023-06-28','Holiday ','Tomorrow College will remain closed on account of Bakrid.'),
 ('2023-07-07','Hall Ticket issue','Your annual exam halltickets will be issued on 08-07-2023.'),
 ('2023-07-10','Sports meet','Dear students , sports day is being held on 12/07/23'),
 ('2023-07-08','Holiday','Tomorrow College will remain closed .'),
 ('2023-06-30','Exam Circular','Dear Students , your exams commences from 08/08/2023'),
 ('2023-07-07','Annual Day','Dear students , annual day is being held on 18/07/23'),
 ('2023-06-13','Exams','Exams starts on 25.07.23');
/*!40000 ALTER TABLE `publishnotice` ENABLE KEYS */;


--
-- Table structure for table `uca`.`stdassignmentdetails`
--

DROP TABLE IF EXISTS `stdassignmentdetails`;
CREATE TABLE `stdassignmentdetails` (
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `sem` varchar(50) DEFAULT NULL,
  `file` longblob,
  `filename` varchar(50) DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`stdassignmentdetails`
--

/*!40000 ALTER TABLE `stdassignmentdetails` DISABLE KEYS */;
INSERT INTO `stdassignmentdetails` (`email`,`subject`,`course`,`sem`,`file`,`filename`,`filetype`,`date`) VALUES 
 ('smartuni.student1@gmail.com','MP','BCA','5',0x4D70206E6F746573,'Mp.txt','text/plain','2023-07-17 13:23:16'),
 ('smartuni.student1@gmail.com','TOC','BCA','5',0x48656C6C6F0A,'WP (1).txt','text/plain','2023-07-17 13:25:27'),
 ('smartuni.student1@gmail.com','TOC','BCA','5','','','application/octet-stream','2023-07-17 21:53:43'),
 ('smartuni.student1@gmail.com','TOC','BCA','5',0x4A617661204E6F746573,'Java.txt','text/plain','2023-07-17 22:03:14'),
 ('smartuni.student1@gmail.com','TOC','BCA','5','','','application/octet-stream','2023-07-17 22:06:47'),
 ('smartuni.student1@gmail.com','TOC','BCA','5',0x544F43206E6F746573,'TOC.txt','text/plain','2023-07-17 22:10:29'),
 ('harsh@gmail.com','System Programming','BCA','6',0x4A617661204E6F746573,'Java.txt','text/plain','2023-07-18 00:42:44');
/*!40000 ALTER TABLE `stdassignmentdetails` ENABLE KEYS */;


--
-- Table structure for table `uca`.`stdregister`
--

DROP TABLE IF EXISTS `stdregister`;
CREATE TABLE `stdregister` (
  `id` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `parentsname` varchar(50) DEFAULT NULL,
  `phoneno` varchar(50) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `semester` varchar(50) DEFAULT NULL,
  `yearofadm` varchar(50) DEFAULT NULL,
  `photo` longblob,
  `password` varchar(50) DEFAULT NULL,
  `confirmpass` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`stdregister`
--

/*!40000 ALTER TABLE `stdregister` DISABLE KEYS */;
INSERT INTO `stdregister` (`id`,`name`,`dob`,`parentsname`,`phoneno`,`emailid`,`course`,`semester`,`yearofadm`,`photo`,`password`,`confirmpass`) VALUES 
 ('S41547','Lalith','2002-10-22','Durgaram','9845793543','seervilalith2202@gmail.com','BCA','6','2020',0x757365722E706E67,'221002','221002'),
 ('S52517','Likith','2002-01-01','Umashankar','7894561230','likith@gmail.com','BCA','6','2020',0x68612E706E67,'010102','010102'),
 ('S78311','Harshith','2002-07-06','Thyagraju','7891234560','harsh@gmail.com','BCA','6','2020',0x656D61696C2E706E67,'060723','060723'),
 ('S22526','Varun','2002-05-04','Rao','7894561231','varun@gmail.com','BCA','5','2020',0x61646D696E312E6A706567,'040523','040523'),
 ('S45663','Ritesh','2002-07-06','Pawar','9876543231','ritesh@gmail.com','BCA','5','2020',0x6D61726B732E706E67,'060723','060723'),
 ('S92113','Darshan','2002-10-18','Lingaiah','9876543787','smartuni.student1@gmail.com','BCA','5','2020',0x686F6D656C6F676F2E706E67,'9630','9630'),
 ('S23329','Nidhi','2002-06-24','Satish','7894561231','nidhisatish24@gmail.com','BCA','6','2020',0x6E6F746963652E706E67,'240602','240602'),
 ('S86980','Harshat','2001-01-01','Ravindra','7894561231','harshar@gmail.com','BCA','5','2020',0x666F6C64657269636F6E2E706E67,'010101','010101');
INSERT INTO `stdregister` (`id`,`name`,`dob`,`parentsname`,`phoneno`,`emailid`,`course`,`semester`,`yearofadm`,`photo`,`password`,`confirmpass`) VALUES 
 ('S88184','Chetan','2001-11-11','Arun','7891234560','chetan@gmail.com','BCA','4','2019',0x666F6C64657269636F6E2E706E67,'111101','111101'),
 ('S57493','Gautham','2002-05-08','Anil','7894561230','gautham@gmail.com','BCA','4','2021',0x666F6C64657269636F6E2E706E67,'080502','080502');
/*!40000 ALTER TABLE `stdregister` ENABLE KEYS */;


--
-- Table structure for table `uca`.`students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `attendance` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`students`
--

/*!40000 ALTER TABLE `students` DISABLE KEYS */;
/*!40000 ALTER TABLE `students` ENABLE KEYS */;


--
-- Table structure for table `uca`.`submitassignment`
--

DROP TABLE IF EXISTS `submitassignment`;
CREATE TABLE `submitassignment` (
  `assignment` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`submitassignment`
--

/*!40000 ALTER TABLE `submitassignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `submitassignment` ENABLE KEYS */;


--
-- Table structure for table `uca`.`uploadnotes`
--

DROP TABLE IF EXISTS `uploadnotes`;
CREATE TABLE `uploadnotes` (
  `course` varchar(50) DEFAULT NULL,
  `semester` varchar(50) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `notes` varchar(10000) DEFAULT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `file_key` varchar(100) DEFAULT NULL,
  `cipher` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uca`.`uploadnotes`
--

/*!40000 ALTER TABLE `uploadnotes` DISABLE KEYS */;
INSERT INTO `uploadnotes` (`course`,`semester`,`subject`,`notes`,`filename`,`date`,`file_key`,`cipher`) VALUES 
 ('BCA','6','WP','Hello','WP.txt','2023-07-11','fTpQRoNZOLwcBmceioUKyg==','mFQbNVxXhrgw+oVA2LlNVA=='),
 ('BCA','5','MP','Mp notes','Mp.txt','2023-07-16','/K9Rn1/aUYNlrt5TdvAsQw==','2E1eRVG8xJjbqZp43unARQ=='),
 ('BCA','5','Java','Java Notes','Java.txt','2023-07-16','MM1dVz+dQi9OAZU8bIZAfA==','zENu9eErZZJm8bkgWbY47A=='),
 ('BCA','6','CNS','CNS Notes','cns.txt','2023-07-16','as8AOp/k0gbTnG1Ne84S5A==','yR5J0Ahhp5W+863RdFz1qA=='),
 ('BCA','5','WP','Hello','WP.txt','2023-07-16','kbFSV8QTU+/Q3qACidCOuw==','1lw7YCMwmytsbWp3bLcfGQ==');
/*!40000 ALTER TABLE `uploadnotes` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
