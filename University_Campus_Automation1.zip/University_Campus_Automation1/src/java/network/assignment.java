/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package network;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/assignment")
@MultipartConfig(maxFileSize = 1073741823)
public class assignment extends HttpServlet {

    private String dbURL = "jdbc:mysql://localhost:3306/uca";
    private String dbUser = "root";
    private String dbPass = "root";

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String fileName="";
        HttpSession session = request.getSession(false);
        String email = (String) session.getAttribute("emailid");
            
        String subject = request.getParameter("subject");
        String course = request.getParameter("course");
        String semester = request.getParameter("semester");
        
        // System.out.println("User Recommend :" + gen + age + marital + edu + interest + content);
        
        InputStream inputStream = null;
        Part filePart = request.getPart("assignment");
        if (filePart != null) {
            String contentDisposition = filePart.getHeader("content-disposition");
            String[] parts = contentDisposition.split(";");

            for (String part : parts) {
                if (part.trim().startsWith("filename")) {
                    fileName = part.substring(part.indexOf('=') + 1).trim().replace("\"", "");
                    break;
                }
            }
            System.out.println(email);
            System.out.println(subject);
            System.out.println(course);
            System.out.println(semester);
            System.out.println(fileName);
            System.out.println(filePart.getName());
            System.out.println(filePart.getSize());
            System.out.println(filePart.getContentType());


            inputStream = filePart.getInputStream();
        }

        Connection conn = null;
        String message = null;

        try {

            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            conn=DriverManager.getConnection(dbURL,dbUser,dbPass);

            //Checking if AID is Available Already
            String sql = "";
            PreparedStatement statement;
           
                sql = "INSERT INTO stdassignmentdetails(email, subject, course, sem, file, filename, filetype, date) values (?, ? , ? , ?, ?, ?, ?, NOW())";
                System.out.println(semester);
                statement = conn.prepareStatement(sql);
                System.out.println(semester);
                statement.setString(1, email);
                statement.setString(2, subject);
                statement.setString(3, course);
                statement.setString(4, semester);
                statement.setString(6, fileName);
                statement.setString(7, filePart.getContentType());
                if (inputStream != null) {
                    statement.setBlob(5, inputStream);
                }
            

            //  statement.setString(1, bio);




            int row = statement.executeUpdate();
            if (row > 0) {

                System.out.println("File upload sucess");
                response.sendRedirect("viewassignment1.jsp?msg=success");
            } else {
                response.sendRedirect("error.jsp?msg=Failed");

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}